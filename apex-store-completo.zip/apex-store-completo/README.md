# APEX Store

Tienda frontend responsive con HTML, CSS y JavaScript. Incluye inicio, catálogo, filtros, páginas de producto, carrito persistente y páginas informativas.

## Abrir localmente
1. Abrí esta carpeta en Visual Studio Code.
2. Instalá la extensión **Live Server**.
3. Clic derecho en `index.html` → **Open with Live Server**.

## Logo oficial
Copiá `APEX_logo_fondo_transparente.png` en `assets/images/logo/`. El archivo original no estaba disponible como archivo accesible al generar el proyecto, por eso no se inventó un reemplazo.

## Editar productos
Modificá `js/store.js` y `window.APEX_PRODUCTS`. Cada producto tiene `id`, `name`, `category`, `price`, `description`, `image`, `featured`, `createdAt`, `available` y `badge`. Los productos actuales son ejemplos: verificá precios, proveedor, stock, autenticidad y condiciones antes de publicar.

## Contacto y checkout
Editá `js/config.js`: configurá `contactEmail` y, si querés consultas por WhatsApp, `whatsappNumber` en formato internacional sin `+`, espacios ni guiones. El checkout de Mercado Pago requiere backend y credenciales privadas; nunca pongas el Access Token en JavaScript del navegador.

## GitHub
```bash
git init
git add .
git commit -m "Crear tienda APEX"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/apex-store.git
git push -u origin main
```
Creá antes un repositorio vacío y reemplazá la URL por la tuya.

## Publicación
GitHub Pages puede publicar el frontend estático. Para pagos online necesitás alojar el backend en un servicio compatible con Node.js, configurar las variables privadas y usar HTTPS. Los textos legales son plantillas que deben adaptarse a los países en los que vendas.

## Funciones incluidas
- Diseño responsive y menú móvil.
- Catálogo, búsqueda por URL, categorías, filtros de precio y ordenamiento.
- Fichas de producto.
- Carrito con cantidades, eliminación y persistencia en `localStorage`.
- Formulario de contacto que prepara un email.
- Base de integración con Mercado Pago Checkout Pro en `backend/`.

El estado del pago debe verificarse con el proveedor antes de entregar pedidos. Para producción se recomienda añadir base de datos, inventario real, persistencia de órdenes y notificaciones/webhooks de pago.
