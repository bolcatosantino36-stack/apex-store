Carpeta para banners propios optimizados. El hero actual usa una fotografía remota de ejemplo.
