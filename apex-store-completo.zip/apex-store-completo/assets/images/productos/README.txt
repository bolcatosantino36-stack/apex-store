Guardá aquí fotos optimizadas y referencialas desde js/store.js con rutas como assets/images/productos/mi-producto.webp.
