Carpeta para iconos del proyecto.
