# Backend Mercado Pago Checkout Pro

1. Instalá Node.js LTS.
2. Desde terminal: `cd backend`
3. Ejecutá `npm install`.
4. Copiá `.env.example` a `.env` y completá las variables privadas.
5. Ejecutá `npm start`.
6. En `js/config.js`, poné `useMercadoPagoCheckout: true`.
7. En producción, alojá el backend con HTTPS y guardá `MERCADOPAGO_ACCESS_TOKEN` como variable privada del hosting, nunca en el navegador.

La lista de precios de `server.js` es de demostración y debe sincronizarse con un catálogo real. Para producción necesitás persistencia de órdenes, stock, notificaciones/webhooks de pago y verificación del estado antes de entregar pedidos.
