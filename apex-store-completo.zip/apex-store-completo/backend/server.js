import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { MercadoPagoConfig, Preference } from "mercadopago";
dotenv.config();
const app=express();app.use(express.json());app.use(cors({origin:process.env.FRONTEND_ORIGIN||"http://127.0.0.1:5500"}));
const port=Number(process.env.PORT||4242),token=process.env.MERCADOPAGO_ACCESS_TOKEN,baseUrl=process.env.PUBLIC_BASE_URL;
app.get("/api/health",(_req,res)=>res.json({ok:true,checkoutConfigured:Boolean(token&&baseUrl)}));
app.post("/api/create-preference",async(req,res)=>{
 if(!token||!baseUrl)return res.status(503).json({error:"Checkout no configurado en el servidor."});
 const incoming=req.body?.items;if(!Array.isArray(incoming)||!incoming.length)return res.status(400).json({error:"El carrito está vacío."});
 const catalog={"frag-001":{title:"Fragancia Signature",unit_price:45000},"tech-001":{title:"Auriculares inalámbricos",unit_price:78000},"acc-001":{title:"Accesorio Essential",unit_price:22000},"frag-002":{title:"Fragancia Noir",unit_price:52000}};
 const items=[];for(const item of incoming){const p=catalog[item.id],quantity=Number(item.quantity);if(!p||!Number.isInteger(quantity)||quantity<1||quantity>99)return res.status(400).json({error:"Producto o cantidad inválida."});items.push({id:item.id,title:p.title,quantity,unit_price:p.unit_price,currency_id:"ARS"});}
 try{const client=new MercadoPagoConfig({accessToken:token});const preference=new Preference(client);const result=await preference.create({body:{items,back_urls:{success:`${baseUrl}/pago-resultado.html?estado=exito`,failure:`${baseUrl}/pago-resultado.html?estado=error`,pending:`${baseUrl}/pago-resultado.html?estado=pendiente`},auto_return:"approved",statement_descriptor:"APEX"}});res.json({id:result.id,init_point:result.init_point});}
 catch(error){console.error("Mercado Pago preference error:",error?.message||error);res.status(502).json({error:"No se pudo crear la preferencia de pago."});}
});
app.listen(port,()=>console.log(`APEX checkout backend en http://localhost:${port}`));
