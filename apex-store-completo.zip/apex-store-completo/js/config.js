/* Ajustá estos datos antes de publicar. No coloques claves secretas en archivos frontend. */
window.APEX_CONFIG = {
  storeName: "APEX",
  currency: "ARS",
  locale: "es-AR",
  contactEmail: "cambiar-por-tu-email@example.com",
  whatsappNumber: "", // formato internacional sin +, espacios ni guiones. Ejemplo: 54911XXXXXXXX
  checkoutEndpoint: "/api/create-preference",
  useMercadoPagoCheckout: false
};