(() => {
 const KEY="apex-cart-v1";
 const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}};
 const save=items=>{localStorage.setItem(KEY,JSON.stringify(items));updateCount();};
 const updateCount=()=>{const n=read().reduce((s,x)=>s+x.quantity,0);document.querySelectorAll(".cart-count").forEach(el=>el.textContent=n);};
 const add=(id,quantity=1)=>{const p=window.APEX_PRODUCTS.find(x=>x.id===id);if(!p)return;const items=read(),item=items.find(x=>x.id===id);if(item)item.quantity=Math.min(99,item.quantity+quantity);else items.push({id,quantity:Math.min(99,quantity)});save(items);showToast(`${p.name} se agregó al carrito.`);};
 function showToast(message){let el=document.getElementById("apex-toast");if(!el){el=document.createElement("div");el.id="apex-toast";el.style.cssText="position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#f4f4f4;color:#0b0b0c;padding:13px 20px;border-radius:999px;z-index:1000;box-shadow:0 8px 35px #0008;font-size:14px;max-width:90vw;text-align:center";document.body.appendChild(el);}el.textContent=message;el.hidden=false;clearTimeout(window.__apexToastTimer);window.__apexToastTimer=setTimeout(()=>el.hidden=true,2500);}
 document.addEventListener("click",e=>{const b=e.target.closest(".add-to-cart");if(b)add(b.dataset.id,1);});
 document.addEventListener("DOMContentLoaded",updateCount);
 window.APEX_CART={read,save,add,updateCount,showToast};
})();