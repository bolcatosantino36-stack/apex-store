document.addEventListener("DOMContentLoaded",()=>{
 const target=document.getElementById("catalog-products");if(!target)return;
 const cat=document.getElementById("category-filter"),min=document.getElementById("min-price"),max=document.getElementById("max-price"),avail=document.getElementById("available-filter"),sort=document.getElementById("sort-select"),count=document.getElementById("result-count"),empty=document.getElementById("no-results");
 [...new Set(window.APEX_PRODUCTS.map(p=>p.category))].sort().forEach(c=>cat.add(new Option(c,c)));
 const params=new URLSearchParams(location.search);if(params.get("categoria"))cat.value=params.get("categoria");const q=(params.get("q")||"").trim().toLowerCase();
 function render(){let list=window.APEX_PRODUCTS.filter(p=>(!cat.value||p.category===cat.value)&&(!min.value||p.price>=Number(min.value))&&(!max.value||p.price<=Number(max.value))&&(!avail.checked||p.available)&&(!q||`${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q)));
 if(sort.value==="price-asc")list.sort((a,b)=>a.price-b.price);if(sort.value==="price-desc")list.sort((a,b)=>b.price-a.price);if(sort.value==="newest")list.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));if(sort.value==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
 target.innerHTML=list.map(window.APEX_card).join("");count.textContent=`${list.length} producto${list.length===1?"":"s"}`;empty.hidden=list.length>0;}
 [cat,min,max,avail,sort].forEach(el=>el.addEventListener("input",render));document.getElementById("clear-filters").addEventListener("click",()=>{cat.value="";min.value="";max.value="";avail.checked=false;sort.value="featured";render();});render();
});